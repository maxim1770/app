--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE app_test;
--
-- Name: app_test; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE app_test WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE app_test OWNER TO postgres;

\connect app_test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: biblebookabbr; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebookabbr AS ENUM (
    'Mk',
    'Mt',
    'Lk',
    'Jn',
    'Act',
    'Jac',
    '_1Pet',
    '_2Pet',
    '_1Jn',
    '_2Jn',
    '_3Jn',
    'Juda',
    'Rom',
    '_1Cor',
    '_2Cor',
    'Gal',
    'Eph',
    'Phil',
    'Col',
    '_1Thes',
    '_2Thes',
    '_1Tim',
    '_2Tim',
    'Tit',
    'Phlm',
    'Hebr',
    'Apok',
    'Ps',
    'Gen',
    'Ex',
    'Lev',
    'Num',
    'Deut',
    'Nav',
    'Judg',
    'Rth',
    '_1Sam',
    '_2Sam',
    '_1King',
    '_2King',
    'Tov',
    'Est'
);


ALTER TYPE public.biblebookabbr OWNER TO postgres;

--
-- Name: biblebookabbrru; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebookabbrru AS ENUM (
    'Jn',
    'Lk',
    'Mk',
    'Mt',
    'Act',
    'Jac',
    '_1Pet',
    '_2Pet',
    '_1Jn',
    '_2Jn',
    '_3Jn',
    'Juda',
    'Rom',
    '_1Cor',
    '_2Cor',
    'Gal',
    'Eph',
    'Phil',
    'Col',
    '_1Thes',
    '_2Thes',
    '_1Tim',
    '_2Tim',
    'Tit',
    'Phlm',
    'Hebr',
    'Apok',
    'Ps',
    'Gen',
    'Ex',
    'Lev',
    'Num',
    'Deut',
    'Nav',
    'Judg',
    'Rth',
    '_1Sam',
    '_2Sam',
    '_1King',
    '_2King',
    'Tov',
    'Est'
);


ALTER TYPE public.biblebookabbrru OWNER TO postgres;

--
-- Name: biblebookpart; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebookpart AS ENUM (
    'evangel',
    'apostle',
    'psaltyr',
    'pjatiknizhie_moiseja'
);


ALTER TYPE public.biblebookpart OWNER TO postgres;

--
-- Name: biblebookpartru; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebookpartru AS ENUM (
    'evangel',
    'apostle',
    'psaltyr',
    'pjatiknizhie_moiseja'
);


ALTER TYPE public.biblebookpartru OWNER TO postgres;

--
-- Name: biblebooktestament; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebooktestament AS ENUM (
    'new_testament',
    'old_testament'
);


ALTER TYPE public.biblebooktestament OWNER TO postgres;

--
-- Name: biblebooktestamentru; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.biblebooktestamentru AS ENUM (
    'new_testament',
    'old_testament'
);


ALTER TYPE public.biblebooktestamentru OWNER TO postgres;

--
-- Name: booksource; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booksource AS ENUM (
    'ot_Limonisa',
    'ot_Paterika',
    'ot_Pandeka',
    'ot_Starchestva'
);


ALTER TYPE public.booksource OWNER TO postgres;

--
-- Name: booktitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booktitle AS ENUM (
    'Prolog',
    'Zhitija_Svjatyh',
    'Mesjatseslov',
    'Evangelie_uchitelnoe',
    'Sbornik_Slov',
    'Sinaksar',
    'Sbornik_Slov_i_Zhitij',
    'Evangelie',
    'Apostol',
    'Evangelie_tolkovoe',
    'Apostol_tolkovyj',
    'Psaltyr',
    'Psaltyr_tolkovaja',
    'Kormchaja',
    'Kormchaja_tolkovaja',
    'Lls',
    'Sluzhby_i_Zhitija_Svjatyh',
    'Paterik'
);


ALTER TYPE public.booktitle OWNER TO postgres;

--
-- Name: booktopic; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booktopic AS ENUM (
    'o_Svjatyh_Ikonah',
    'o_Ljubvi',
    'o_Prichastii',
    'o_Molitve',
    'o_Smirennoj_Mudrosti',
    'o_Smirenii',
    'o_Dolgoterpenii',
    'o_Terpenii',
    'o_Pokajanii',
    'o_Ispovedanii_grehov',
    'o_Dobrodeteli',
    'o_Poslushanii',
    'o_Milostyni',
    'o_Molchanii',
    'o_Nischeljubii',
    'ezhe_ne_osuzhdat',
    'o_pomysle',
    'o_Nakazanii',
    'o_Trude',
    'o_Tsarstvii_Nebesnom',
    'o_muke_beskonechnoj',
    'o_Strashnom_Sude',
    'o_kljanuschihsja',
    'o_leni',
    'o_zavisti',
    'o_sheptanii',
    'o_klevetanii',
    'o_lzhivyh',
    'o_lihoimanii',
    'o_dajuschih_v_lihvu',
    'o_gneve',
    'o_derzosti',
    'o_jarosti',
    'o_pjanstve',
    'o_objadenii',
    'o_usopshih',
    'o_smerti',
    'o_gordosti',
    'ezhe_ne_otchajatsja',
    'o_snah',
    'o_rabah',
    'o_Svjatom_Prichastii',
    'o_suete',
    'o_Kaznjah_Bozhiih',
    'o_Proschenii_grehov',
    'o_Nravah_Dobryh',
    'ezhe_Dobro_est_Truditsja_svoimi_rukami',
    'ezhe_ne_Propovedati_Bozhestva_nevernym',
    'o_mnogoimenii',
    'o_Pochitanii_Knizhnom',
    'o_Chesti_Iereistei',
    'o_Uchiteljah',
    'o_Strannoljubii',
    'o_Upovanii_na_Boga',
    'o_Episkopah',
    'o_Svjaschennikah',
    'o_Oblichenii',
    'o_Srebroljubii',
    'o_pechali',
    'o_Hitrosti_Knizhnoj',
    'o_zlobe',
    'o_sogreshajuschih_i_ne_Kajuschihsja',
    'o_jadenii',
    'o_Epitimjah',
    'o_Videnii'
);


ALTER TYPE public.booktopic OWNER TO postgres;

--
-- Name: booktype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booktype AS ENUM (
    'Slovo',
    'Pouchenie',
    'Pritcha',
    'Povest',
    'Pohvala',
    'Slovo_Pohvalnoe',
    'Prolog',
    'Beseda',
    'Sluzhba',
    'Nakazanie',
    '_istorija',
    'slovo_istorija',
    'pouchenie_istorija',
    'Sinaksar',
    'Slovo_Vospominatelnoe',
    'Zachalo',
    'Psalom',
    'Pravilo',
    'Tropar',
    'Kondak',
    'Poslanie',
    'Nravouchenie',
    'Glavy',
    'Skazanie',
    'Oglashenie',
    'Stih',
    'Molitva'
);


ALTER TYPE public.booktype OWNER TO postgres;

--
-- Name: bookutil; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.bookutil AS ENUM (
    'Upominanie',
    'Chudo'
);


ALTER TYPE public.bookutil OWNER TO postgres;

--
-- Name: citytitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.citytitle AS ENUM (
    'afon',
    'balkany',
    'bolgarija',
    'vatoped',
    'venetsija',
    'vizantija',
    'vladimir',
    'vologda',
    'volokolamsk',
    'germanija',
    'grachanitsa',
    'gretsija',
    'gruzija',
    'dafni',
    'dechani',
    'italija',
    'kastorija',
    'kiev',
    'kipr',
    'konstantinopol',
    'makedonija',
    'meteory',
    'milan',
    'moskva',
    'nereditsa',
    'novgorod',
    'ohrid',
    'pskov',
    'ravenna',
    'rim',
    'rostov',
    'rumynija',
    'russkij_sever',
    'rus',
    'saloniki',
    'serbija',
    'sirija',
    'sitsilija',
    'solun',
    'solvychegodsk',
    'sopochany',
    'tver',
    'ferapontovo',
    'hosios_lukas',
    'chefalu',
    'jaroslavl',
    'velikij_novgorod',
    'kavkaz_gruzija',
    'perejaslavl_zalesskij',
    'rossija',
    'belorussija',
    'velikij_ustjug',
    'vizantija_konstantinopol',
    'vologodskie_zemli',
    'vostochnaja_evropa_serbija',
    'gretsija_afon',
    'gretsija_krit',
    'zapadnaja_evropa_gretsija_afon',
    'zapadnaja_evropa_gretsija_krit',
    'zapadnaja_evropa_italija',
    'zapadnaja_evropa_italija_venetsija',
    'krit',
    'krym',
    'novgorod_ili_russkij_sever',
    'novgorodskaja_provintsija',
    'provintsija',
    'rossija_provintsija',
    'sever',
    'severo_vostochnaja_rus_rostovskaja_shkola',
    'solovetskij_monastyr',
    'srednjaja_rus',
    'tihvin',
    'tsentralnaja_moskva',
    'tsentralnaja_rossija',
    'jaroslavskaja_obl_jaroslavl'
);


ALTER TYPE public.citytitle OWNER TO postgres;

--
-- Name: cyclenum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.cyclenum AS ENUM (
    'cycle_1',
    'cycle_2',
    'cycle_3'
);


ALTER TYPE public.cyclenum OWNER TO postgres;

--
-- Name: dignitytitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.dignitytitle AS ENUM (
    'papa_rimskij',
    'patriarh',
    'mitropolit',
    'arhiepiskop',
    'episkop',
    'arhimandrit',
    'igumen',
    'igumenija',
    'ieromonah',
    'presviter',
    'arhidiakon',
    'ierodiakon',
    'diakon',
    'diakonisa',
    'chtets',
    'shimonah',
    'shimonahinja',
    'monah',
    'monahinja',
    'inok',
    'inokinja'
);


ALTER TYPE public.dignitytitle OWNER TO postgres;

--
-- Name: divineservicetitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.divineservicetitle AS ENUM (
    'liturgy',
    'matins',
    'vespers'
);


ALTER TYPE public.divineservicetitle OWNER TO postgres;

--
-- Name: facesanctitytitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.facesanctitytitle AS ENUM (
    'apostol',
    'apostol_ot_70_ti',
    'ravnoapostolnyj',
    'ravnoapostolnaja',
    'vethozavetnyj_patriarh',
    'prorok',
    'prorochitsa',
    'Hrista_radi_jurodivyj',
    'velikomuchenitsa',
    'velikomuchenik',
    'muchenitsa',
    'muchenik',
    'prepodobnomuchenitsa',
    'prepodobnomuchenik',
    'svjaschennomuchenik',
    'ispovednik',
    'ispovednitsa',
    'bessrebrenik',
    'blazhennyj',
    'blazhennaja',
    'blagovernyj',
    'blagovernaja',
    'blagovernyj_knjaz',
    'blagovernaja_knjaginja',
    'pravednyj',
    'pravednaja',
    'prepodobnyj',
    'prepodobnaja',
    'svjatoj',
    'svjataja',
    'svjatitel'
);


ALTER TYPE public.facesanctitytitle OWNER TO postgres;

--
-- Name: fundtitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.fundtitle AS ENUM (
    'f_i',
    'sol',
    'sof',
    'gilf',
    'pogod',
    'kir_bel',
    'f_7',
    'f_37',
    'f_87',
    'f_98',
    'f_113',
    'f_173i',
    'f_304i',
    'f_304iii',
    'f_556',
    'oldp',
    'f_218',
    'f_178i',
    'f_256',
    'f_228'
);


ALTER TYPE public.fundtitle OWNER TO postgres;

--
-- Name: holidaycategorytitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.holidaycategorytitle AS ENUM (
    'prazdniki_hristovy',
    'prazdniki_bogorodichny',
    'prazdniki_predtechevy',
    'cathedral_saints',
    'den_pamjati',
    'obretenie_moschej',
    'perenesenie_moschej',
    'vtoroe_perenesenie_moschej',
    'predprazdnstvo',
    'poprazdnstvo'
);


ALTER TYPE public.holidaycategorytitle OWNER TO postgres;

--
-- Name: librarytitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.librarytitle AS ENUM (
    'nlr',
    'rsl'
);


ALTER TYPE public.librarytitle OWNER TO postgres;

--
-- Name: molitvabooktype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.molitvabooktype AS ENUM (
    'Tropar',
    'Kondak'
);


ALTER TYPE public.molitvabooktype OWNER TO postgres;

--
-- Name: movabledayabbr; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.movabledayabbr AS ENUM (
    'sun',
    'mon',
    'tue',
    'wed',
    'thu',
    'fri',
    'sat'
);


ALTER TYPE public.movabledayabbr OWNER TO postgres;

--
-- Name: movabledayabbrru; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.movabledayabbrru AS ENUM (
    'sun',
    'mon',
    'tue',
    'wed',
    'thu',
    'fri',
    'sat'
);


ALTER TYPE public.movabledayabbrru OWNER TO postgres;

--
-- Name: numbookmarks; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.numbookmarks AS ENUM (
    'few',
    'middle',
    'many',
    'all'
);


ALTER TYPE public.numbookmarks OWNER TO postgres;

--
-- Name: pageposition; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.pageposition AS ENUM (
    'left',
    'right'
);


ALTER TYPE public.pageposition OWNER TO postgres;

--
-- Name: posttitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.posttitle AS ENUM (
    'Rozhdestvenskij_Post',
    'Velikij_Post',
    'Strastnaja_Sedmitsa',
    'Petrov_Post',
    'Uspenskij_Post'
);


ALTER TYPE public.posttitle OWNER TO postgres;

--
-- Name: tipikonpriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipikonpriority AS ENUM (
    'Velikij_Prazdnik',
    'Srednij_Prazdnik_Vsenoschnoe_Bdenie',
    'Srednij_Prazdnik',
    'Malyj_Prazdnik_Slavoslovnaja_Sluzhba',
    'Malyj_Prazdnik'
);


ALTER TYPE public.tipikonpriority OWNER TO postgres;

--
-- Name: tipikontitle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipikontitle AS ENUM (
    'Velikij_Prazdnik',
    'Srednij_Prazdnik',
    'Malyj_Prazdnik',
    'Malyj_Prazdnik_Slavoslovnaja_Sluzhba',
    'Srednij_Prazdnik_Vsenoschnoe_Bdenie'
);


ALTER TYPE public.tipikontitle OWNER TO postgres;

--
-- Name: сathedralslug; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."сathedralslug" AS ENUM (
    'pravila_svjatyh_apostolov',
    'svjatogo_apostola_pavla_osobno_pravil',
    'togo_zh_pravila_o_usopshih_i_vlasteleh',
    'vselenskij_sobor_1_nikejskij',
    'pomestnyj_sobor_ankirskij',
    'pomestnyj_sobor_neokesarijskij',
    'pomestnyj_sobor_gangrskij',
    'pomestnyj_sobor_antiohijskij',
    'pomestnyj_sobor_laodikijskij',
    'vselenskij_sobor_2_konstantinopolskij',
    'vselenskij_sobor_3_efesskij',
    'vselenskij_sobor_4_halkidonskij',
    'pomestnyj_sobor_sardikijskij',
    'pomestnyj_sobor_karfagenskij',
    'vselenskij_sobor_6_konstantinopolskij_trulskij',
    'vselenskij_sobor_7_nikejskij',
    'pomestnyj_sobor_konstantinopolskij_dvukratnyj',
    'pomestnyj_sobor_konstantinopolskij',
    'pravila_svjatogo_vasilija_velikogo_ot_poslanij',
    'svjatago_vasilja_o_vremeni_sogreshajuschih_vkrattse',
    'iustinijana_razlichnyja_zapovedi'
);


ALTER TYPE public."сathedralslug" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: before_after_holiday; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.before_after_holiday (
    id integer NOT NULL,
    great_holiday_id integer NOT NULL
);


ALTER TABLE public.before_after_holiday OWNER TO postgres;

--
-- Name: before_after_holiday_day_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.before_after_holiday_day_association (
    day_id integer NOT NULL,
    before_after_holiday_id integer NOT NULL,
    is_last_day boolean
);


ALTER TABLE public.before_after_holiday_day_association OWNER TO postgres;

--
-- Name: before_after_holiday_movable_day_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.before_after_holiday_movable_day_association (
    movable_day_id integer NOT NULL,
    before_after_holiday_id integer NOT NULL,
    is_last_day boolean
);


ALTER TABLE public.before_after_holiday_movable_day_association OWNER TO postgres;

--
-- Name: bible_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bible_book (
    id integer NOT NULL,
    testament public.biblebooktestament NOT NULL,
    testament_ru public.biblebooktestamentru NOT NULL,
    part public.biblebookpart,
    part_ru public.biblebookpartru,
    title character varying(50) NOT NULL,
    abbr public.biblebookabbr NOT NULL,
    abbr_ru public.biblebookabbrru NOT NULL
);


ALTER TABLE public.bible_book OWNER TO postgres;

--
-- Name: bible_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bible_book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bible_book_id_seq OWNER TO postgres;

--
-- Name: bible_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bible_book_id_seq OWNED BY public.bible_book.id;


--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    id integer NOT NULL,
    title public.booktitle,
    parent_id integer,
    author_id integer,
    type public.booktype,
    bookmark_title character varying(700),
    day_id integer
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_id_seq OWNER TO postgres;

--
-- Name: book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_id_seq OWNED BY public.book.id;


--
-- Name: bookmark; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookmark (
    manuscript_id integer NOT NULL,
    book_id integer NOT NULL,
    first_page_id integer NOT NULL,
    end_page_id integer NOT NULL,
    chapter_num smallint
);


ALTER TABLE public.bookmark OWNER TO postgres;

--
-- Name: cathedral; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cathedral (
    id integer NOT NULL,
    slug public."сathedralslug" NOT NULL,
    title character varying(150) NOT NULL,
    num_rules smallint NOT NULL,
    num_saints smallint,
    year_id integer
);


ALTER TABLE public.cathedral OWNER TO postgres;

--
-- Name: cathedral_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cathedral_book (
    id integer NOT NULL,
    rule_num smallint NOT NULL,
    cathedral_id integer NOT NULL
);


ALTER TABLE public.cathedral_book OWNER TO postgres;

--
-- Name: cathedral_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cathedral_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cathedral_id_seq OWNER TO postgres;

--
-- Name: cathedral_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cathedral_id_seq OWNED BY public.cathedral.id;


--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    id integer NOT NULL,
    title public.citytitle NOT NULL
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.city_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.city_id_seq OWNER TO postgres;

--
-- Name: city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.city_id_seq OWNED BY public.city.id;


--
-- Name: cycle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cycle (
    id integer NOT NULL,
    num public.cyclenum NOT NULL,
    title character varying(50) NOT NULL,
    "desc" character varying(200)
);


ALTER TABLE public.cycle OWNER TO postgres;

--
-- Name: cycle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cycle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cycle_id_seq OWNER TO postgres;

--
-- Name: cycle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cycle_id_seq OWNED BY public.cycle.id;


--
-- Name: date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.date (
    day_id integer NOT NULL,
    movable_day_id integer NOT NULL,
    year smallint NOT NULL,
    post_id integer
);


ALTER TABLE public.date OWNER TO postgres;

--
-- Name: day; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.day (
    id integer NOT NULL,
    month smallint NOT NULL,
    day smallint NOT NULL
);


ALTER TABLE public.day OWNER TO postgres;

--
-- Name: day_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.day_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.day_id_seq OWNER TO postgres;

--
-- Name: day_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.day_id_seq OWNED BY public.day.id;


--
-- Name: dignity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dignity (
    id integer NOT NULL,
    title public.dignitytitle NOT NULL
);


ALTER TABLE public.dignity OWNER TO postgres;

--
-- Name: dignity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dignity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dignity_id_seq OWNER TO postgres;

--
-- Name: dignity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dignity_id_seq OWNED BY public.dignity.id;


--
-- Name: divine_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.divine_service (
    id integer NOT NULL,
    title public.divineservicetitle NOT NULL
);


ALTER TABLE public.divine_service OWNER TO postgres;

--
-- Name: divine_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.divine_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.divine_service_id_seq OWNER TO postgres;

--
-- Name: divine_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.divine_service_id_seq OWNED BY public.divine_service.id;


--
-- Name: face_sanctity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.face_sanctity (
    id integer NOT NULL,
    title public.facesanctitytitle NOT NULL
);


ALTER TABLE public.face_sanctity OWNER TO postgres;

--
-- Name: face_sanctity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.face_sanctity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.face_sanctity_id_seq OWNER TO postgres;

--
-- Name: face_sanctity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.face_sanctity_id_seq OWNED BY public.face_sanctity.id;


--
-- Name: fund; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fund (
    id integer NOT NULL,
    title public.fundtitle NOT NULL,
    library public.librarytitle NOT NULL
);


ALTER TABLE public.fund OWNER TO postgres;

--
-- Name: fund_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fund_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fund_id_seq OWNER TO postgres;

--
-- Name: fund_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fund_id_seq OWNED BY public.fund.id;


--
-- Name: holiday; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holiday (
    id integer NOT NULL,
    title character varying(250),
    slug character varying(200) NOT NULL,
    holiday_category_id integer,
    year_id integer,
    day_id integer,
    movable_day_id integer,
    tipikon_id integer
);


ALTER TABLE public.holiday OWNER TO postgres;

--
-- Name: holiday_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holiday_book (
    id integer NOT NULL,
    holiday_id integer,
    book_util public.bookutil,
    saint_id integer
);


ALTER TABLE public.holiday_book OWNER TO postgres;

--
-- Name: holiday_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holiday_category (
    id integer NOT NULL,
    title public.holidaycategorytitle NOT NULL
);


ALTER TABLE public.holiday_category OWNER TO postgres;

--
-- Name: holiday_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.holiday_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.holiday_category_id_seq OWNER TO postgres;

--
-- Name: holiday_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.holiday_category_id_seq OWNED BY public.holiday_category.id;


--
-- Name: holiday_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.holiday_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.holiday_id_seq OWNER TO postgres;

--
-- Name: holiday_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.holiday_id_seq OWNED BY public.holiday.id;


--
-- Name: icon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.icon (
    id integer NOT NULL,
    "desc" character varying(450),
    pravicon_id smallint,
    year_id integer NOT NULL,
    city_id integer,
    gallerix_id bigint,
    shm_id integer
);


ALTER TABLE public.icon OWNER TO postgres;

--
-- Name: icon_holiday_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.icon_holiday_association (
    icon_id integer NOT NULL,
    holiday_id integer NOT NULL,
    is_use_slug boolean
);


ALTER TABLE public.icon_holiday_association OWNER TO postgres;

--
-- Name: icon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.icon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.icon_id_seq OWNER TO postgres;

--
-- Name: icon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.icon_id_seq OWNED BY public.icon.id;


--
-- Name: lls_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lls_book (
    id integer NOT NULL,
    year_id integer,
    is_chapter boolean,
    has_year_at_start boolean
);


ALTER TABLE public.lls_book OWNER TO postgres;

--
-- Name: manuscript; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript (
    id integer NOT NULL,
    title character varying(170),
    neb_slug character varying(200),
    code_title character varying(20) NOT NULL,
    code character varying(36) NOT NULL,
    handwriting smallint NOT NULL,
    not_numbered_pages json NOT NULL,
    first_page_position public.pageposition NOT NULL,
    year_id integer NOT NULL,
    fund_id integer,
    all_num_pages smallint,
    preview_page_id integer,
    num_bookmarks public.numbookmarks
);


ALTER TABLE public.manuscript OWNER TO postgres;

--
-- Name: manuscript_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manuscript_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manuscript_id_seq OWNER TO postgres;

--
-- Name: manuscript_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manuscript_id_seq OWNED BY public.manuscript.id;


--
-- Name: molitva_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.molitva_book (
    id integer NOT NULL,
    holiday_id integer NOT NULL,
    glas_num smallint
);


ALTER TABLE public.molitva_book OWNER TO postgres;

--
-- Name: movable_date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movable_date (
    id integer NOT NULL,
    movable_day_id integer NOT NULL,
    divine_service_id integer
);


ALTER TABLE public.movable_date OWNER TO postgres;

--
-- Name: movable_date_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movable_date_book (
    id integer NOT NULL,
    movable_day_id integer NOT NULL
);


ALTER TABLE public.movable_date_book OWNER TO postgres;

--
-- Name: movable_date_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movable_date_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movable_date_id_seq OWNER TO postgres;

--
-- Name: movable_date_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.movable_date_id_seq OWNED BY public.movable_date.id;


--
-- Name: movable_day; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movable_day (
    id integer NOT NULL,
    abbr public.movabledayabbr NOT NULL,
    abbr_ru public.movabledayabbrru NOT NULL,
    title character varying(30),
    week_id integer NOT NULL
);


ALTER TABLE public.movable_day OWNER TO postgres;

--
-- Name: movable_day_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movable_day_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movable_day_id_seq OWNER TO postgres;

--
-- Name: movable_day_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.movable_day_id_seq OWNED BY public.movable_day.id;


--
-- Name: page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page (
    id integer NOT NULL,
    num smallint NOT NULL,
    "position" public.pageposition NOT NULL
);


ALTER TABLE public.page OWNER TO postgres;

--
-- Name: page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_id_seq OWNER TO postgres;

--
-- Name: page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.page_id_seq OWNED BY public.page.id;


--
-- Name: post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post (
    id integer NOT NULL,
    title public.posttitle NOT NULL
);


ALTER TABLE public.post OWNER TO postgres;

--
-- Name: post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_id_seq OWNER TO postgres;

--
-- Name: post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_id_seq OWNED BY public.post.id;


--
-- Name: psaltyr_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.psaltyr_book (
    id integer NOT NULL,
    num smallint NOT NULL,
    bible_book_id integer NOT NULL
);


ALTER TABLE public.psaltyr_book OWNER TO postgres;

--
-- Name: saint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saint (
    id integer NOT NULL,
    name character varying(150),
    slug character varying(200) NOT NULL,
    dignity_id integer,
    face_sanctity_id integer,
    name_in_dative character varying(150)
);


ALTER TABLE public.saint OWNER TO postgres;

--
-- Name: saint_holiday_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saint_holiday_association (
    saint_id integer NOT NULL,
    holiday_id integer NOT NULL
);


ALTER TABLE public.saint_holiday_association OWNER TO postgres;

--
-- Name: saint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.saint_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.saint_id_seq OWNER TO postgres;

--
-- Name: saint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.saint_id_seq OWNED BY public.saint.id;


--
-- Name: tipikon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipikon (
    id integer NOT NULL,
    title public.tipikontitle NOT NULL,
    priority public.tipikonpriority NOT NULL
);


ALTER TABLE public.tipikon OWNER TO postgres;

--
-- Name: tipikon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipikon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipikon_id_seq OWNER TO postgres;

--
-- Name: tipikon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipikon_id_seq OWNED BY public.tipikon.id;


--
-- Name: topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topic (
    id integer NOT NULL,
    title public.booktopic NOT NULL
);


ALTER TABLE public.topic OWNER TO postgres;

--
-- Name: topic_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topic_book (
    id integer NOT NULL,
    source public.booksource
);


ALTER TABLE public.topic_book OWNER TO postgres;

--
-- Name: topic_book_topic_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topic_book_topic_association (
    topic_id integer NOT NULL,
    topic_book_id integer NOT NULL
);


ALTER TABLE public.topic_book_topic_association OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.topic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.topic_id_seq OWNER TO postgres;

--
-- Name: topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.topic_id_seq OWNED BY public.topic.id;


--
-- Name: week; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week (
    id integer NOT NULL,
    title character varying(100),
    num smallint,
    sunday_title character varying(50),
    sunday_num smallint,
    cycle_id integer NOT NULL
);


ALTER TABLE public.week OWNER TO postgres;

--
-- Name: week_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.week_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.week_id_seq OWNER TO postgres;

--
-- Name: week_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.week_id_seq OWNED BY public.week.id;


--
-- Name: year; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.year (
    id integer NOT NULL,
    title character varying(30) NOT NULL,
    year smallint NOT NULL
);


ALTER TABLE public.year OWNER TO postgres;

--
-- Name: year_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.year_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.year_id_seq OWNER TO postgres;

--
-- Name: year_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.year_id_seq OWNED BY public.year.id;


--
-- Name: zachalo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zachalo (
    id integer NOT NULL,
    num smallint NOT NULL,
    title character varying(30),
    bible_book_id integer NOT NULL
);


ALTER TABLE public.zachalo OWNER TO postgres;

--
-- Name: zachalo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zachalo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zachalo_id_seq OWNER TO postgres;

--
-- Name: zachalo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zachalo_id_seq OWNED BY public.zachalo.id;


--
-- Name: zachalo_movable_date_association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zachalo_movable_date_association (
    zachalo_id integer NOT NULL,
    movable_date_id integer NOT NULL
);


ALTER TABLE public.zachalo_movable_date_association OWNER TO postgres;

--
-- Name: bible_book id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bible_book ALTER COLUMN id SET DEFAULT nextval('public.bible_book_id_seq'::regclass);


--
-- Name: book id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book ALTER COLUMN id SET DEFAULT nextval('public.book_id_seq'::regclass);


--
-- Name: cathedral id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral ALTER COLUMN id SET DEFAULT nextval('public.cathedral_id_seq'::regclass);


--
-- Name: city id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city ALTER COLUMN id SET DEFAULT nextval('public.city_id_seq'::regclass);


--
-- Name: cycle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cycle ALTER COLUMN id SET DEFAULT nextval('public.cycle_id_seq'::regclass);


--
-- Name: day id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.day ALTER COLUMN id SET DEFAULT nextval('public.day_id_seq'::regclass);


--
-- Name: dignity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dignity ALTER COLUMN id SET DEFAULT nextval('public.dignity_id_seq'::regclass);


--
-- Name: divine_service id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divine_service ALTER COLUMN id SET DEFAULT nextval('public.divine_service_id_seq'::regclass);


--
-- Name: face_sanctity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.face_sanctity ALTER COLUMN id SET DEFAULT nextval('public.face_sanctity_id_seq'::regclass);


--
-- Name: fund id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund ALTER COLUMN id SET DEFAULT nextval('public.fund_id_seq'::regclass);


--
-- Name: holiday id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday ALTER COLUMN id SET DEFAULT nextval('public.holiday_id_seq'::regclass);


--
-- Name: holiday_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_category ALTER COLUMN id SET DEFAULT nextval('public.holiday_category_id_seq'::regclass);


--
-- Name: icon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon ALTER COLUMN id SET DEFAULT nextval('public.icon_id_seq'::regclass);


--
-- Name: manuscript id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript ALTER COLUMN id SET DEFAULT nextval('public.manuscript_id_seq'::regclass);


--
-- Name: movable_date id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date ALTER COLUMN id SET DEFAULT nextval('public.movable_date_id_seq'::regclass);


--
-- Name: movable_day id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_day ALTER COLUMN id SET DEFAULT nextval('public.movable_day_id_seq'::regclass);


--
-- Name: page id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page ALTER COLUMN id SET DEFAULT nextval('public.page_id_seq'::regclass);


--
-- Name: post id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post ALTER COLUMN id SET DEFAULT nextval('public.post_id_seq'::regclass);


--
-- Name: saint id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint ALTER COLUMN id SET DEFAULT nextval('public.saint_id_seq'::regclass);


--
-- Name: tipikon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipikon ALTER COLUMN id SET DEFAULT nextval('public.tipikon_id_seq'::regclass);


--
-- Name: topic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic ALTER COLUMN id SET DEFAULT nextval('public.topic_id_seq'::regclass);


--
-- Name: week id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week ALTER COLUMN id SET DEFAULT nextval('public.week_id_seq'::regclass);


--
-- Name: year id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.year ALTER COLUMN id SET DEFAULT nextval('public.year_id_seq'::regclass);


--
-- Name: zachalo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo ALTER COLUMN id SET DEFAULT nextval('public.zachalo_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/3926.dat';

--
-- Data for Name: before_after_holiday; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.before_after_holiday (id, great_holiday_id) FROM stdin;
\.
COPY public.before_after_holiday (id, great_holiday_id) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: before_after_holiday_day_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.before_after_holiday_day_association (day_id, before_after_holiday_id, is_last_day) FROM stdin;
\.
COPY public.before_after_holiday_day_association (day_id, before_after_holiday_id, is_last_day) FROM '$$PATH$$/3940.dat';

--
-- Data for Name: before_after_holiday_movable_day_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.before_after_holiday_movable_day_association (movable_day_id, before_after_holiday_id, is_last_day) FROM stdin;
\.
COPY public.before_after_holiday_movable_day_association (movable_day_id, before_after_holiday_id, is_last_day) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: bible_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bible_book (id, testament, testament_ru, part, part_ru, title, abbr, abbr_ru) FROM stdin;
\.
COPY public.bible_book (id, testament, testament_ru, part, part_ru, title, abbr, abbr_ru) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (id, title, parent_id, author_id, type, bookmark_title, day_id) FROM stdin;
\.
COPY public.book (id, title, parent_id, author_id, type, bookmark_title, day_id) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: bookmark; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookmark (manuscript_id, book_id, first_page_id, end_page_id, chapter_num) FROM stdin;
\.
COPY public.bookmark (manuscript_id, book_id, first_page_id, end_page_id, chapter_num) FROM '$$PATH$$/3920.dat';

--
-- Data for Name: cathedral; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cathedral (id, slug, title, num_rules, num_saints, year_id) FROM stdin;
\.
COPY public.cathedral (id, slug, title, num_rules, num_saints, year_id) FROM '$$PATH$$/3936.dat';

--
-- Data for Name: cathedral_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cathedral_book (id, rule_num, cathedral_id) FROM stdin;
\.
COPY public.cathedral_book (id, rule_num, cathedral_id) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (id, title) FROM stdin;
\.
COPY public.city (id, title) FROM '$$PATH$$/3923.dat';

--
-- Data for Name: cycle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cycle (id, num, title, "desc") FROM stdin;
\.
COPY public.cycle (id, num, title, "desc") FROM '$$PATH$$/3895.dat';

--
-- Data for Name: date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.date (day_id, movable_day_id, year, post_id) FROM stdin;
\.
COPY public.date (day_id, movable_day_id, year, post_id) FROM '$$PATH$$/3919.dat';

--
-- Data for Name: day; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.day (id, month, day) FROM stdin;
\.
COPY public.day (id, month, day) FROM '$$PATH$$/3893.dat';

--
-- Data for Name: dignity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dignity (id, title) FROM stdin;
\.
COPY public.dignity (id, title) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: divine_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.divine_service (id, title) FROM stdin;
\.
COPY public.divine_service (id, title) FROM '$$PATH$$/3897.dat';

--
-- Data for Name: face_sanctity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.face_sanctity (id, title) FROM stdin;
\.
COPY public.face_sanctity (id, title) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: fund; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fund (id, title, library) FROM stdin;
\.
COPY public.fund (id, title, library) FROM '$$PATH$$/3901.dat';

--
-- Data for Name: holiday; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holiday (id, title, slug, holiday_category_id, year_id, day_id, movable_day_id, tipikon_id) FROM stdin;
\.
COPY public.holiday (id, title, slug, holiday_category_id, year_id, day_id, movable_day_id, tipikon_id) FROM '$$PATH$$/3917.dat';

--
-- Data for Name: holiday_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holiday_book (id, holiday_id, book_util, saint_id) FROM stdin;
\.
COPY public.holiday_book (id, holiday_id, book_util, saint_id) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: holiday_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holiday_category (id, title) FROM stdin;
\.
COPY public.holiday_category (id, title) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: icon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.icon (id, "desc", pravicon_id, year_id, city_id, gallerix_id, shm_id) FROM stdin;
\.
COPY public.icon (id, "desc", pravicon_id, year_id, city_id, gallerix_id, shm_id) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: icon_holiday_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.icon_holiday_association (icon_id, holiday_id, is_use_slug) FROM stdin;
\.
COPY public.icon_holiday_association (icon_id, holiday_id, is_use_slug) FROM '$$PATH$$/3931.dat';

--
-- Data for Name: lls_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lls_book (id, year_id, is_chapter, has_year_at_start) FROM stdin;
\.
COPY public.lls_book (id, year_id, is_chapter, has_year_at_start) FROM '$$PATH$$/3938.dat';

--
-- Data for Name: manuscript; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript (id, title, neb_slug, code_title, code, handwriting, not_numbered_pages, first_page_position, year_id, fund_id, all_num_pages, preview_page_id, num_bookmarks) FROM stdin;
\.
COPY public.manuscript (id, title, neb_slug, code_title, code, handwriting, not_numbered_pages, first_page_position, year_id, fund_id, all_num_pages, preview_page_id, num_bookmarks) FROM '$$PATH$$/3909.dat';

--
-- Data for Name: molitva_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.molitva_book (id, holiday_id, glas_num) FROM stdin;
\.
COPY public.molitva_book (id, holiday_id, glas_num) FROM '$$PATH$$/3927.dat';

--
-- Data for Name: movable_date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movable_date (id, movable_day_id, divine_service_id) FROM stdin;
\.
COPY public.movable_date (id, movable_day_id, divine_service_id) FROM '$$PATH$$/3915.dat';

--
-- Data for Name: movable_date_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movable_date_book (id, movable_day_id) FROM stdin;
\.
COPY public.movable_date_book (id, movable_day_id) FROM '$$PATH$$/3928.dat';

--
-- Data for Name: movable_day; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movable_day (id, abbr, abbr_ru, title, week_id) FROM stdin;
\.
COPY public.movable_day (id, abbr, abbr_ru, title, week_id) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page (id, num, "position") FROM stdin;
\.
COPY public.page (id, num, "position") FROM '$$PATH$$/3903.dat';

--
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.post (id, title) FROM stdin;
\.
COPY public.post (id, title) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: psaltyr_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.psaltyr_book (id, num, bible_book_id) FROM stdin;
\.
COPY public.psaltyr_book (id, num, bible_book_id) FROM '$$PATH$$/3934.dat';

--
-- Data for Name: saint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saint (id, name, slug, dignity_id, face_sanctity_id, name_in_dative) FROM stdin;
\.
COPY public.saint (id, name, slug, dignity_id, face_sanctity_id, name_in_dative) FROM '$$PATH$$/3907.dat';

--
-- Data for Name: saint_holiday_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saint_holiday_association (saint_id, holiday_id) FROM stdin;
\.
COPY public.saint_holiday_association (saint_id, holiday_id) FROM '$$PATH$$/3932.dat';

--
-- Data for Name: tipikon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipikon (id, title, priority) FROM stdin;
\.
COPY public.tipikon (id, title, priority) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.topic (id, title) FROM stdin;
\.
COPY public.topic (id, title) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: topic_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.topic_book (id, source) FROM stdin;
\.
COPY public.topic_book (id, source) FROM '$$PATH$$/3918.dat';

--
-- Data for Name: topic_book_topic_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.topic_book_topic_association (topic_id, topic_book_id) FROM stdin;
\.
COPY public.topic_book_topic_association (topic_id, topic_book_id) FROM '$$PATH$$/3948.dat';

--
-- Data for Name: week; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week (id, title, num, sunday_title, sunday_num, cycle_id) FROM stdin;
\.
COPY public.week (id, title, num, sunday_title, sunday_num, cycle_id) FROM '$$PATH$$/3905.dat';

--
-- Data for Name: year; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.year (id, title, year) FROM stdin;
\.
COPY public.year (id, title, year) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: zachalo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zachalo (id, num, title, bible_book_id) FROM stdin;
\.
COPY public.zachalo (id, num, title, bible_book_id) FROM '$$PATH$$/3930.dat';

--
-- Data for Name: zachalo_movable_date_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zachalo_movable_date_association (zachalo_id, movable_date_id) FROM stdin;
\.
COPY public.zachalo_movable_date_association (zachalo_id, movable_date_id) FROM '$$PATH$$/3933.dat';

--
-- Name: bible_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bible_book_id_seq', 505, true);


--
-- Name: book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_id_seq', 64407, true);


--
-- Name: cathedral_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cathedral_id_seq', 35, true);


--
-- Name: city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.city_id_seq', 121, true);


--
-- Name: cycle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cycle_id_seq', 34, true);


--
-- Name: day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.day_id_seq', 366, true);


--
-- Name: dignity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dignity_id_seq', 21, true);


--
-- Name: divine_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.divine_service_id_seq', 72, true);


--
-- Name: face_sanctity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.face_sanctity_id_seq', 31, true);


--
-- Name: fund_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fund_id_seq', 15, true);


--
-- Name: holiday_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.holiday_category_id_seq', 8, true);


--
-- Name: holiday_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.holiday_id_seq', 1662, true);


--
-- Name: icon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.icon_id_seq', 7201, true);


--
-- Name: manuscript_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscript_id_seq', 93, true);


--
-- Name: movable_date_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movable_date_id_seq', 5570, true);


--
-- Name: movable_day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movable_day_id_seq', 5512, true);


--
-- Name: page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.page_id_seq', 127373, true);


--
-- Name: post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_id_seq', 5, true);


--
-- Name: saint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.saint_id_seq', 2111, true);


--
-- Name: tipikon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipikon_id_seq', 3, true);


--
-- Name: topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.topic_id_seq', 65, true);


--
-- Name: week_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week_id_seq', 829, true);


--
-- Name: year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.year_id_seq', 1138, true);


--
-- Name: zachalo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zachalo_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: before_after_holiday_day_association before_after_holiday_day_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_day_association
    ADD CONSTRAINT before_after_holiday_day_association_pkey PRIMARY KEY (day_id, before_after_holiday_id);


--
-- Name: before_after_holiday_movable_day_association before_after_holiday_movable_day_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_movable_day_association
    ADD CONSTRAINT before_after_holiday_movable_day_association_pkey PRIMARY KEY (movable_day_id, before_after_holiday_id);


--
-- Name: before_after_holiday before_after_holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday
    ADD CONSTRAINT before_after_holiday_pkey PRIMARY KEY (id);


--
-- Name: bible_book bible_book_abbr_ru_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bible_book
    ADD CONSTRAINT bible_book_abbr_ru_key UNIQUE (abbr_ru);


--
-- Name: bible_book bible_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bible_book
    ADD CONSTRAINT bible_book_pkey PRIMARY KEY (id);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (id);


--
-- Name: bookmark bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmark
    ADD CONSTRAINT bookmark_pkey PRIMARY KEY (manuscript_id, book_id);


--
-- Name: cathedral_book cathedral_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral_book
    ADD CONSTRAINT cathedral_book_pkey PRIMARY KEY (id);


--
-- Name: cathedral cathedral_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral
    ADD CONSTRAINT cathedral_pkey PRIMARY KEY (id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (id);


--
-- Name: cycle cycle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cycle
    ADD CONSTRAINT cycle_pkey PRIMARY KEY (id);


--
-- Name: cycle cycle_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cycle
    ADD CONSTRAINT cycle_title_key UNIQUE (title);


--
-- Name: date date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT date_pkey PRIMARY KEY (day_id, movable_day_id, year);


--
-- Name: day day_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.day
    ADD CONSTRAINT day_pkey PRIMARY KEY (id);


--
-- Name: dignity dignity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dignity
    ADD CONSTRAINT dignity_pkey PRIMARY KEY (id);


--
-- Name: divine_service divine_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divine_service
    ADD CONSTRAINT divine_service_pkey PRIMARY KEY (id);


--
-- Name: face_sanctity face_sanctity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.face_sanctity
    ADD CONSTRAINT face_sanctity_pkey PRIMARY KEY (id);


--
-- Name: fund fund_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund
    ADD CONSTRAINT fund_pkey PRIMARY KEY (id);


--
-- Name: holiday_book holiday_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_book
    ADD CONSTRAINT holiday_book_pkey PRIMARY KEY (id);


--
-- Name: holiday_category holiday_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_category
    ADD CONSTRAINT holiday_category_pkey PRIMARY KEY (id);


--
-- Name: holiday holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_pkey PRIMARY KEY (id);


--
-- Name: icon_holiday_association icon_holiday_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon_holiday_association
    ADD CONSTRAINT icon_holiday_association_pkey PRIMARY KEY (icon_id, holiday_id);


--
-- Name: icon icon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT icon_pkey PRIMARY KEY (id);


--
-- Name: lls_book lls_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lls_book
    ADD CONSTRAINT lls_book_pkey PRIMARY KEY (id);


--
-- Name: manuscript manuscript_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript
    ADD CONSTRAINT manuscript_pkey PRIMARY KEY (id);


--
-- Name: molitva_book molitva_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.molitva_book
    ADD CONSTRAINT molitva_book_pkey PRIMARY KEY (id);


--
-- Name: movable_date_book movable_date_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date_book
    ADD CONSTRAINT movable_date_book_pkey PRIMARY KEY (id);


--
-- Name: movable_date movable_date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date
    ADD CONSTRAINT movable_date_pkey PRIMARY KEY (id);


--
-- Name: movable_day movable_day_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_day
    ADD CONSTRAINT movable_day_pkey PRIMARY KEY (id);


--
-- Name: movable_day movable_day_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_day
    ADD CONSTRAINT movable_day_title_key UNIQUE (title);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: post post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT post_pkey PRIMARY KEY (id);


--
-- Name: psaltyr_book psaltyr_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psaltyr_book
    ADD CONSTRAINT psaltyr_book_pkey PRIMARY KEY (id);


--
-- Name: saint_holiday_association saint_holiday_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint_holiday_association
    ADD CONSTRAINT saint_holiday_association_pkey PRIMARY KEY (saint_id, holiday_id);


--
-- Name: saint saint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint
    ADD CONSTRAINT saint_pkey PRIMARY KEY (id);


--
-- Name: tipikon tipikon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipikon
    ADD CONSTRAINT tipikon_pkey PRIMARY KEY (id);


--
-- Name: topic_book topic_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic_book
    ADD CONSTRAINT topic_book_pkey PRIMARY KEY (id);


--
-- Name: topic_book_topic_association topic_book_topic_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic_book_topic_association
    ADD CONSTRAINT topic_book_topic_association_pkey PRIMARY KEY (topic_id, topic_book_id);


--
-- Name: topic topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic
    ADD CONSTRAINT topic_pkey PRIMARY KEY (id);


--
-- Name: week week_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week
    ADD CONSTRAINT week_pkey PRIMARY KEY (id);


--
-- Name: week week_sunday_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week
    ADD CONSTRAINT week_sunday_title_key UNIQUE (sunday_title);


--
-- Name: week week_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week
    ADD CONSTRAINT week_title_key UNIQUE (title);


--
-- Name: year year_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.year
    ADD CONSTRAINT year_pkey PRIMARY KEY (id);


--
-- Name: year year_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.year
    ADD CONSTRAINT year_title_key UNIQUE (title);


--
-- Name: zachalo_movable_date_association zachalo_movable_date_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo_movable_date_association
    ADD CONSTRAINT zachalo_movable_date_association_pkey PRIMARY KEY (zachalo_id, movable_date_id);


--
-- Name: zachalo zachalo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo
    ADD CONSTRAINT zachalo_pkey PRIMARY KEY (id);


--
-- Name: before_after_holiday_day_association_before_after_holid_13ba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX before_after_holiday_day_association_before_after_holid_13ba ON public.before_after_holiday_day_association USING btree (before_after_holiday_id);


--
-- Name: before_after_holiday_day_association_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX before_after_holiday_day_association_day_id_idx ON public.before_after_holiday_day_association USING btree (day_id);


--
-- Name: before_after_holiday_great_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX before_after_holiday_great_holiday_id_idx ON public.before_after_holiday USING btree (great_holiday_id);


--
-- Name: before_after_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX before_after_holiday_id_idx ON public.before_after_holiday USING btree (id);


--
-- Name: before_after_holiday_movable_day_association_before_aft_a520; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX before_after_holiday_movable_day_association_before_aft_a520 ON public.before_after_holiday_movable_day_association USING btree (before_after_holiday_id);


--
-- Name: before_after_holiday_movable_day_association_movable_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX before_after_holiday_movable_day_association_movable_day_id_idx ON public.before_after_holiday_movable_day_association USING btree (movable_day_id);


--
-- Name: bible_book_abbr_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bible_book_abbr_idx ON public.bible_book USING btree (abbr);


--
-- Name: bible_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bible_book_id_idx ON public.bible_book USING btree (id);


--
-- Name: bible_book_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bible_book_title_idx ON public.bible_book USING btree (title);


--
-- Name: book_author_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_author_id_idx ON public.book USING btree (author_id);


--
-- Name: book_bookmark_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_bookmark_title_idx ON public.book USING btree (bookmark_title);


--
-- Name: book_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_day_id_idx ON public.book USING btree (day_id);


--
-- Name: book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX book_id_idx ON public.book USING btree (id);


--
-- Name: book_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_parent_id_idx ON public.book USING btree (parent_id);


--
-- Name: book_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_title_idx ON public.book USING btree (title);


--
-- Name: book_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX book_type_idx ON public.book USING btree (type);


--
-- Name: bookmark_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookmark_book_id_idx ON public.bookmark USING btree (book_id);


--
-- Name: bookmark_chapter_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookmark_chapter_num_idx ON public.bookmark USING btree (chapter_num);


--
-- Name: bookmark_end_page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookmark_end_page_id_idx ON public.bookmark USING btree (end_page_id);


--
-- Name: bookmark_first_page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookmark_first_page_id_idx ON public.bookmark USING btree (first_page_id);


--
-- Name: bookmark_manuscript_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookmark_manuscript_id_idx ON public.bookmark USING btree (manuscript_id);


--
-- Name: cathedral_book_cathedral_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cathedral_book_cathedral_id_idx ON public.cathedral_book USING btree (cathedral_id);


--
-- Name: cathedral_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cathedral_book_id_idx ON public.cathedral_book USING btree (id);


--
-- Name: cathedral_book_rule_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cathedral_book_rule_num_idx ON public.cathedral_book USING btree (rule_num);


--
-- Name: cathedral_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cathedral_id_idx ON public.cathedral USING btree (id);


--
-- Name: cathedral_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cathedral_slug_idx ON public.cathedral USING btree (slug);


--
-- Name: cathedral_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cathedral_title_idx ON public.cathedral USING btree (title);


--
-- Name: cathedral_year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cathedral_year_id_idx ON public.cathedral USING btree (year_id);


--
-- Name: city_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX city_id_idx ON public.city USING btree (id);


--
-- Name: city_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX city_title_idx ON public.city USING btree (title);


--
-- Name: cycle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cycle_id_idx ON public.cycle USING btree (id);


--
-- Name: cycle_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX cycle_num_idx ON public.cycle USING btree (num);


--
-- Name: date_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX date_day_id_idx ON public.date USING btree (day_id);


--
-- Name: date_post_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX date_post_id_idx ON public.date USING btree (post_id);


--
-- Name: day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX day_id_idx ON public.day USING btree (id);


--
-- Name: day_month_day_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX day_month_day_idx ON public.day USING btree (month, day);


--
-- Name: day_month_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX day_month_idx ON public.day USING btree (month);


--
-- Name: dignity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dignity_id_idx ON public.dignity USING btree (id);


--
-- Name: dignity_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dignity_title_idx ON public.dignity USING btree (title);


--
-- Name: divine_service_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX divine_service_id_idx ON public.divine_service USING btree (id);


--
-- Name: divine_service_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX divine_service_title_idx ON public.divine_service USING btree (title);


--
-- Name: face_sanctity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX face_sanctity_id_idx ON public.face_sanctity USING btree (id);


--
-- Name: face_sanctity_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX face_sanctity_title_idx ON public.face_sanctity USING btree (title);


--
-- Name: fund_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fund_id_idx ON public.fund USING btree (id);


--
-- Name: fund_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fund_title_idx ON public.fund USING btree (title);


--
-- Name: holiday_book_book_util_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_book_book_util_idx ON public.holiday_book USING btree (book_util);


--
-- Name: holiday_book_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_book_holiday_id_idx ON public.holiday_book USING btree (holiday_id);


--
-- Name: holiday_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX holiday_book_id_idx ON public.holiday_book USING btree (id);


--
-- Name: holiday_book_saint_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_book_saint_id_idx ON public.holiday_book USING btree (saint_id);


--
-- Name: holiday_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX holiday_category_id_idx ON public.holiday_category USING btree (id);


--
-- Name: holiday_category_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX holiday_category_title_idx ON public.holiday_category USING btree (title);


--
-- Name: holiday_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_day_id_idx ON public.holiday USING btree (day_id);


--
-- Name: holiday_holiday_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_holiday_category_id_idx ON public.holiday USING btree (holiday_category_id);


--
-- Name: holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX holiday_id_idx ON public.holiday USING btree (id);


--
-- Name: holiday_movable_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_movable_day_id_idx ON public.holiday USING btree (movable_day_id);


--
-- Name: holiday_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX holiday_slug_idx ON public.holiday USING btree (slug);


--
-- Name: holiday_tipikon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_tipikon_id_idx ON public.holiday USING btree (tipikon_id);


--
-- Name: holiday_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_title_idx ON public.holiday USING btree (title);


--
-- Name: holiday_year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX holiday_year_id_idx ON public.holiday USING btree (year_id);


--
-- Name: icon_city_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX icon_city_id_idx ON public.icon USING btree (city_id);


--
-- Name: icon_gallerix_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX icon_gallerix_id_idx ON public.icon USING btree (gallerix_id);


--
-- Name: icon_holiday_association_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX icon_holiday_association_holiday_id_idx ON public.icon_holiday_association USING btree (holiday_id);


--
-- Name: icon_holiday_association_icon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX icon_holiday_association_icon_id_idx ON public.icon_holiday_association USING btree (icon_id);


--
-- Name: icon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX icon_id_idx ON public.icon USING btree (id);


--
-- Name: icon_pravicon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX icon_pravicon_id_idx ON public.icon USING btree (pravicon_id);


--
-- Name: icon_shm_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX icon_shm_id_idx ON public.icon USING btree (shm_id);


--
-- Name: icon_year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX icon_year_id_idx ON public.icon USING btree (year_id);


--
-- Name: lls_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX lls_book_id_idx ON public.lls_book USING btree (id);


--
-- Name: lls_book_year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lls_book_year_id_idx ON public.lls_book USING btree (year_id);


--
-- Name: manuscript_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX manuscript_code_idx ON public.manuscript USING btree (code);


--
-- Name: manuscript_code_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX manuscript_code_title_idx ON public.manuscript USING btree (code_title);


--
-- Name: manuscript_fund_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_fund_id_idx ON public.manuscript USING btree (fund_id);


--
-- Name: manuscript_handwriting_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_handwriting_idx ON public.manuscript USING btree (handwriting);


--
-- Name: manuscript_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX manuscript_id_idx ON public.manuscript USING btree (id);


--
-- Name: manuscript_neb_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX manuscript_neb_slug_idx ON public.manuscript USING btree (neb_slug);


--
-- Name: manuscript_num_bookmarks_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_num_bookmarks_idx ON public.manuscript USING btree (num_bookmarks);


--
-- Name: manuscript_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_title_idx ON public.manuscript USING btree (title);


--
-- Name: manuscript_year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_year_id_idx ON public.manuscript USING btree (year_id);


--
-- Name: molitva_book_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX molitva_book_holiday_id_idx ON public.molitva_book USING btree (holiday_id);


--
-- Name: molitva_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX molitva_book_id_idx ON public.molitva_book USING btree (id);


--
-- Name: movable_date_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX movable_date_book_id_idx ON public.movable_date_book USING btree (id);


--
-- Name: movable_date_book_movable_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_date_book_movable_day_id_idx ON public.movable_date_book USING btree (movable_day_id);


--
-- Name: movable_date_divine_service_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_date_divine_service_id_idx ON public.movable_date USING btree (divine_service_id);


--
-- Name: movable_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX movable_date_id_idx ON public.movable_date USING btree (id);


--
-- Name: movable_date_movable_day_id_divine_service_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_date_movable_day_id_divine_service_id_idx ON public.movable_date USING btree (movable_day_id, divine_service_id);


--
-- Name: movable_date_movable_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_date_movable_day_id_idx ON public.movable_date USING btree (movable_day_id);


--
-- Name: movable_day_abbr_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_day_abbr_idx ON public.movable_day USING btree (abbr);


--
-- Name: movable_day_abbr_week_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_day_abbr_week_id_idx ON public.movable_day USING btree (abbr, week_id);


--
-- Name: movable_day_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX movable_day_id_idx ON public.movable_day USING btree (id);


--
-- Name: movable_day_week_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movable_day_week_id_idx ON public.movable_day USING btree (week_id);


--
-- Name: page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX page_id_idx ON public.page USING btree (id);


--
-- Name: page_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_num_idx ON public.page USING btree (num);


--
-- Name: post_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX post_id_idx ON public.post USING btree (id);


--
-- Name: post_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX post_title_idx ON public.post USING btree (title);


--
-- Name: psaltyr_book_bible_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX psaltyr_book_bible_book_id_idx ON public.psaltyr_book USING btree (bible_book_id);


--
-- Name: psaltyr_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX psaltyr_book_id_idx ON public.psaltyr_book USING btree (id);


--
-- Name: psaltyr_book_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX psaltyr_book_num_idx ON public.psaltyr_book USING btree (num);


--
-- Name: saint_dignity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_dignity_id_idx ON public.saint USING btree (dignity_id);


--
-- Name: saint_face_sanctity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_face_sanctity_id_idx ON public.saint USING btree (face_sanctity_id);


--
-- Name: saint_holiday_association_holiday_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_holiday_association_holiday_id_idx ON public.saint_holiday_association USING btree (holiday_id);


--
-- Name: saint_holiday_association_saint_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_holiday_association_saint_id_idx ON public.saint_holiday_association USING btree (saint_id);


--
-- Name: saint_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX saint_id_idx ON public.saint USING btree (id);


--
-- Name: saint_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_name_idx ON public.saint USING btree (name);


--
-- Name: saint_name_in_dative_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saint_name_in_dative_idx ON public.saint USING btree (name_in_dative);


--
-- Name: saint_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX saint_slug_idx ON public.saint USING btree (slug);


--
-- Name: tipikon_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tipikon_id_idx ON public.tipikon USING btree (id);


--
-- Name: tipikon_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tipikon_priority_idx ON public.tipikon USING btree (priority);


--
-- Name: tipikon_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tipikon_title_idx ON public.tipikon USING btree (title);


--
-- Name: topic_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX topic_book_id_idx ON public.topic_book USING btree (id);


--
-- Name: topic_book_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX topic_book_source_idx ON public.topic_book USING btree (source);


--
-- Name: topic_book_topic_association_topic_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX topic_book_topic_association_topic_book_id_idx ON public.topic_book_topic_association USING btree (topic_book_id);


--
-- Name: topic_book_topic_association_topic_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX topic_book_topic_association_topic_id_idx ON public.topic_book_topic_association USING btree (topic_id);


--
-- Name: topic_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX topic_id_idx ON public.topic USING btree (id);


--
-- Name: topic_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX topic_title_idx ON public.topic USING btree (title);


--
-- Name: week_cycle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX week_cycle_id_idx ON public.week USING btree (cycle_id);


--
-- Name: week_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX week_id_idx ON public.week USING btree (id);


--
-- Name: week_sunday_num_cycle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX week_sunday_num_cycle_id_idx ON public.week USING btree (sunday_num, cycle_id);


--
-- Name: week_sunday_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX week_sunday_num_idx ON public.week USING btree (sunday_num);


--
-- Name: year_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX year_id_idx ON public.year USING btree (id);


--
-- Name: year_year_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX year_year_idx ON public.year USING btree (year);


--
-- Name: zachalo_bible_book_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_bible_book_id_idx ON public.zachalo USING btree (bible_book_id);


--
-- Name: zachalo_bible_book_id_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_bible_book_id_num_idx ON public.zachalo USING btree (bible_book_id, num);


--
-- Name: zachalo_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX zachalo_id_idx ON public.zachalo USING btree (id);


--
-- Name: zachalo_movable_date_association_movable_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_movable_date_association_movable_date_id_idx ON public.zachalo_movable_date_association USING btree (movable_date_id);


--
-- Name: zachalo_movable_date_association_zachalo_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_movable_date_association_zachalo_id_idx ON public.zachalo_movable_date_association USING btree (zachalo_id);


--
-- Name: zachalo_num_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_num_idx ON public.zachalo USING btree (num);


--
-- Name: zachalo_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX zachalo_title_idx ON public.zachalo USING btree (title);


--
-- Name: before_after_holiday_day_association before_after_holiday_day_association_before_after_holid_1ab6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_day_association
    ADD CONSTRAINT before_after_holiday_day_association_before_after_holid_1ab6 FOREIGN KEY (before_after_holiday_id) REFERENCES public.before_after_holiday(id);


--
-- Name: before_after_holiday_day_association before_after_holiday_day_association_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_day_association
    ADD CONSTRAINT before_after_holiday_day_association_day_id_fkey FOREIGN KEY (day_id) REFERENCES public.day(id);


--
-- Name: before_after_holiday before_after_holiday_great_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday
    ADD CONSTRAINT before_after_holiday_great_holiday_id_fkey FOREIGN KEY (great_holiday_id) REFERENCES public.holiday(id);


--
-- Name: before_after_holiday before_after_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday
    ADD CONSTRAINT before_after_holiday_id_fkey FOREIGN KEY (id) REFERENCES public.holiday(id);


--
-- Name: before_after_holiday_movable_day_association before_after_holiday_movable_day_association_before_aft_dc9d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_movable_day_association
    ADD CONSTRAINT before_after_holiday_movable_day_association_before_aft_dc9d FOREIGN KEY (before_after_holiday_id) REFERENCES public.before_after_holiday(id);


--
-- Name: before_after_holiday_movable_day_association before_after_holiday_movable_day_association_movable_da_46f4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.before_after_holiday_movable_day_association
    ADD CONSTRAINT before_after_holiday_movable_day_association_movable_da_46f4 FOREIGN KEY (movable_day_id) REFERENCES public.movable_day(id);


--
-- Name: book book_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.saint(id);


--
-- Name: book book_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_day_id_fkey FOREIGN KEY (day_id) REFERENCES public.day(id);


--
-- Name: book book_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.book(id);


--
-- Name: bookmark bookmark_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmark
    ADD CONSTRAINT bookmark_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.book(id);


--
-- Name: bookmark bookmark_end_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmark
    ADD CONSTRAINT bookmark_end_page_id_fkey FOREIGN KEY (end_page_id) REFERENCES public.page(id);


--
-- Name: bookmark bookmark_first_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmark
    ADD CONSTRAINT bookmark_first_page_id_fkey FOREIGN KEY (first_page_id) REFERENCES public.page(id);


--
-- Name: bookmark bookmark_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookmark
    ADD CONSTRAINT bookmark_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscript(id);


--
-- Name: cathedral_book cathedral_book_cathedral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral_book
    ADD CONSTRAINT cathedral_book_cathedral_id_fkey FOREIGN KEY (cathedral_id) REFERENCES public.cathedral(id);


--
-- Name: cathedral_book cathedral_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral_book
    ADD CONSTRAINT cathedral_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: cathedral cathedral_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cathedral
    ADD CONSTRAINT cathedral_year_id_fkey FOREIGN KEY (year_id) REFERENCES public.year(id);


--
-- Name: date date_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT date_day_id_fkey FOREIGN KEY (day_id) REFERENCES public.day(id);


--
-- Name: date date_movable_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT date_movable_day_id_fkey FOREIGN KEY (movable_day_id) REFERENCES public.movable_day(id);


--
-- Name: date date_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT date_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.post(id);


--
-- Name: holiday_book holiday_book_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_book
    ADD CONSTRAINT holiday_book_holiday_id_fkey FOREIGN KEY (holiday_id) REFERENCES public.holiday(id);


--
-- Name: holiday_book holiday_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_book
    ADD CONSTRAINT holiday_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: holiday_book holiday_book_saint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday_book
    ADD CONSTRAINT holiday_book_saint_id_fkey FOREIGN KEY (saint_id) REFERENCES public.saint(id);


--
-- Name: holiday holiday_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_day_id_fkey FOREIGN KEY (day_id) REFERENCES public.day(id);


--
-- Name: holiday holiday_holiday_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_holiday_category_id_fkey FOREIGN KEY (holiday_category_id) REFERENCES public.holiday_category(id);


--
-- Name: holiday holiday_movable_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_movable_day_id_fkey FOREIGN KEY (movable_day_id) REFERENCES public.movable_day(id);


--
-- Name: holiday holiday_tipikon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_tipikon_id_fkey FOREIGN KEY (tipikon_id) REFERENCES public.tipikon(id);


--
-- Name: holiday holiday_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_year_id_fkey FOREIGN KEY (year_id) REFERENCES public.year(id);


--
-- Name: icon icon_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT icon_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.city(id);


--
-- Name: icon_holiday_association icon_holiday_association_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon_holiday_association
    ADD CONSTRAINT icon_holiday_association_holiday_id_fkey FOREIGN KEY (holiday_id) REFERENCES public.holiday(id);


--
-- Name: icon_holiday_association icon_holiday_association_icon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon_holiday_association
    ADD CONSTRAINT icon_holiday_association_icon_id_fkey FOREIGN KEY (icon_id) REFERENCES public.icon(id);


--
-- Name: icon icon_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.icon
    ADD CONSTRAINT icon_year_id_fkey FOREIGN KEY (year_id) REFERENCES public.year(id);


--
-- Name: lls_book lls_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lls_book
    ADD CONSTRAINT lls_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: lls_book lls_book_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lls_book
    ADD CONSTRAINT lls_book_year_id_fkey FOREIGN KEY (year_id) REFERENCES public.year(id);


--
-- Name: manuscript manuscript_fund_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript
    ADD CONSTRAINT manuscript_fund_id_fkey FOREIGN KEY (fund_id) REFERENCES public.fund(id);


--
-- Name: manuscript manuscript_preview_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript
    ADD CONSTRAINT manuscript_preview_page_id_fkey FOREIGN KEY (preview_page_id) REFERENCES public.page(id);


--
-- Name: manuscript manuscript_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript
    ADD CONSTRAINT manuscript_year_id_fkey FOREIGN KEY (year_id) REFERENCES public.year(id);


--
-- Name: molitva_book molitva_book_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.molitva_book
    ADD CONSTRAINT molitva_book_holiday_id_fkey FOREIGN KEY (holiday_id) REFERENCES public.holiday(id);


--
-- Name: molitva_book molitva_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.molitva_book
    ADD CONSTRAINT molitva_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: movable_date_book movable_date_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date_book
    ADD CONSTRAINT movable_date_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: movable_date_book movable_date_book_movable_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date_book
    ADD CONSTRAINT movable_date_book_movable_day_id_fkey FOREIGN KEY (movable_day_id) REFERENCES public.movable_day(id);


--
-- Name: movable_date movable_date_divine_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date
    ADD CONSTRAINT movable_date_divine_service_id_fkey FOREIGN KEY (divine_service_id) REFERENCES public.divine_service(id);


--
-- Name: movable_date movable_date_movable_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_date
    ADD CONSTRAINT movable_date_movable_day_id_fkey FOREIGN KEY (movable_day_id) REFERENCES public.movable_day(id);


--
-- Name: movable_day movable_day_week_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movable_day
    ADD CONSTRAINT movable_day_week_id_fkey FOREIGN KEY (week_id) REFERENCES public.week(id);


--
-- Name: psaltyr_book psaltyr_book_bible_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psaltyr_book
    ADD CONSTRAINT psaltyr_book_bible_book_id_fkey FOREIGN KEY (bible_book_id) REFERENCES public.bible_book(id);


--
-- Name: psaltyr_book psaltyr_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.psaltyr_book
    ADD CONSTRAINT psaltyr_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: saint saint_dignity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint
    ADD CONSTRAINT saint_dignity_id_fkey FOREIGN KEY (dignity_id) REFERENCES public.dignity(id);


--
-- Name: saint saint_face_sanctity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint
    ADD CONSTRAINT saint_face_sanctity_id_fkey FOREIGN KEY (face_sanctity_id) REFERENCES public.face_sanctity(id);


--
-- Name: saint_holiday_association saint_holiday_association_holiday_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint_holiday_association
    ADD CONSTRAINT saint_holiday_association_holiday_id_fkey FOREIGN KEY (holiday_id) REFERENCES public.holiday(id);


--
-- Name: saint_holiday_association saint_holiday_association_saint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saint_holiday_association
    ADD CONSTRAINT saint_holiday_association_saint_id_fkey FOREIGN KEY (saint_id) REFERENCES public.saint(id);


--
-- Name: topic_book topic_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic_book
    ADD CONSTRAINT topic_book_id_fkey FOREIGN KEY (id) REFERENCES public.book(id) ON DELETE CASCADE;


--
-- Name: topic_book_topic_association topic_book_topic_association_topic_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic_book_topic_association
    ADD CONSTRAINT topic_book_topic_association_topic_book_id_fkey FOREIGN KEY (topic_book_id) REFERENCES public.topic_book(id) ON DELETE CASCADE;


--
-- Name: topic_book_topic_association topic_book_topic_association_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic_book_topic_association
    ADD CONSTRAINT topic_book_topic_association_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topic(id);


--
-- Name: week week_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week
    ADD CONSTRAINT week_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.cycle(id);


--
-- Name: zachalo zachalo_bible_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo
    ADD CONSTRAINT zachalo_bible_book_id_fkey FOREIGN KEY (bible_book_id) REFERENCES public.bible_book(id);


--
-- Name: zachalo zachalo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo
    ADD CONSTRAINT zachalo_id_fkey FOREIGN KEY (id) REFERENCES public.book(id);


--
-- Name: zachalo_movable_date_association zachalo_movable_date_association_movable_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo_movable_date_association
    ADD CONSTRAINT zachalo_movable_date_association_movable_date_id_fkey FOREIGN KEY (movable_date_id) REFERENCES public.movable_date(id);


--
-- Name: zachalo_movable_date_association zachalo_movable_date_association_zachalo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zachalo_movable_date_association
    ADD CONSTRAINT zachalo_movable_date_association_zachalo_id_fkey FOREIGN KEY (zachalo_id) REFERENCES public.zachalo(id);


--
-- PostgreSQL database dump complete
--

